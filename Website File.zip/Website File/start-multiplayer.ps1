$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$serverPath = Join-Path $projectRoot 'server.js'
$gameUrl = 'http://127.0.0.1:3000'

function Test-CampusServer {
  try {
    $reply = Invoke-RestMethod -Uri "$gameUrl/api/ping" -TimeoutSec 1
    return $reply.service -eq 'campus-service-desk'
  } catch {
    return $false
  }
}

if (-not (Test-CampusServer)) {
  $nodeCommand = Get-Command node -ErrorAction SilentlyContinue
  if (-not $nodeCommand) {
    throw 'Node.js 18 or newer is required. Install Node.js, then run Start Multiplayer.bat again.'
  }

  Start-Process `
    -FilePath $nodeCommand.Source `
    -ArgumentList ('"{0}"' -f $serverPath) `
    -WorkingDirectory $projectRoot `
    -WindowStyle Hidden

  $ready = $false
  for ($attempt = 0; $attempt -lt 40; $attempt++) {
    Start-Sleep -Milliseconds 250
    if (Test-CampusServer) {
      $ready = $true
      break
    }
  }

  if (-not $ready) {
    throw 'The multiplayer server did not start on port 3000. Another app may already be using that port.'
  }
}

Start-Process $gameUrl

