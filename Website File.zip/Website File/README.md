# Campus Quest

## Netlify deployment

Deploy this folder directly to Netlify. There is no build command. The publish directory is `.`.

Players open the same Netlify link, create or join a server, and connect directly through WebRTC. Nobody runs `server.js` or opens another file. Public Nostr relays handle encrypted connection discovery; game data travels directly between players.

For testing, use two different devices, browsers, or one normal window and one private window.

## Optional local Node server

`server.js` remains available for local-network testing or a separately hosted backend:

```
node server.js
```

Open `http://localhost:3000`.
The `PORT` environment variable is respected. A separately hosted Node backend can still be entered under **Settings > Multiplayer server address**, but Netlify multiplayer does not require it.

## Flow

Menu (Play / Settings / Controls) > Play > name + uniform + head > Create Server, Join Server or Play Solo.

- Servers hold 2 to 30 players (the creator picks), have a name, and are either open or protected by a 4-digit PIN.
- The name you type shows above your character for everyone.
- `Esc` in game opens the pause menu (resume, controls, settings, leave).

## Full-window game, camera and buttons

- The game canvas fills the whole window at any size or rotation (no fixed 800x500 box). It is re-sized on every resize.
- The camera zoom is a whole number of screen pixels per game pixel (keeps the pixel art crisp). It is picked so the screen shows about one room: wide screens show the room's full width, tall phones show more height, and the camera pans after the player.
- To zoom the camera in or out, change `CAMERA_ZOOM` (1 = default, 1.5 = closer, 0.5 = wider) near `resizeGameCanvas` in `index.html`. `MIN_VIEW_W` stops tall phones from zooming in too far.
- The buttons (players, customize head, menu, fullscreen) use the images in `Assets/Webp/buttons/`. The files in `Assets/Webp/buttons/cropped/` are trimmed, smaller copies of them that the page actually loads. If you replace a button image, re-crop it and overwrite the matching file in `cropped/`.

## Adding your real uniforms and heads

The demo uniforms are recolors of the base suit and the demo heads are drawn in code.
Replace them in the `UNIFORMS` and `HEAD_CHOICES` lists in `index.html` (search for `DEMO CHOICES`):

```js
{ id: 'nurse', name: 'Nurse', frames: ['n1.webp','n2.webp','n3.webp','n4.webp','n5.webp'] }  // 5 walk frames, 32x32
{ id: 'head2', name: 'Round Head', file: 'head2.webp' }                                      // 32x32
```

Put the image files in `Assets/Webp/`. Ids must be lowercase letters, numbers, `-` or `_`.

## Performance and multiplayer notes

- Startup: all images load and decode in parallel; the multiplayer library loads in the background after the menu is ready.
- Rendering: rooms that are off-screen are not drawn; name tags only touch the page when they move.
- Multiplayer: other players and the professor are smoothed and predicted between network updates. The send rate drops automatically as the room fills (about 15/s for small groups, about 6/s for 20+ players).
- Theme: blue and yellow. The yellow colors are the `--y*` variables near the end of the `<style>` block in `index.html`.

## Room 5 (ramp and garden)

Room 5 is a 1600x500 room at world x=1600, y=1220: to the right of Room 3 (Entrance) and under Room 4 (Campus).
Its art is in `Assets/Webp/room5/` (every layer is 1600x500 with the same origin).

- Room 3 <-> Room 5: walk right along the Entrance platform and through the gap in Room 3's right-hand rail onto the ramp.
- Room 4 <-> Room 5: the grass strip and the parking lane at the bottom of Room 4 carry straight on into Room 5.
- Walkable areas and obstacles are `room5Walk` and `room5Obstacles` in `index.html` (search for `Room 5: the ramp and garden`).
  Positions are Room 5 pixels, so they can be read straight off the art.
- Props that characters walk behind or in front of (bench, palm, bush) are `room5Props`; `depth` is the y of the object's base.
- Room 4's last wheel stopper hangs below Room 4's bottom edge, so Room 5 draws that piece of `room 4/wheel stopper.webp`.

## Room 6 (left of Rooms 2 and 3)

Room 6 is an 800x1720 room at world x=-800, y=0: directly to the left of Room 2 (Admission) and Room 3 (Entrance). Rooms 2 and 3 were not moved or redrawn; the world now starts at `WORLD_MIN_X = -800`.
Its art is in `Assets/Webp/room 6/` (every layer is 800x1720 with the same origin). Look for `Room 6` in `index.html`.

- Room 2 <-> Room 6: the open tiled corridor at the right edge of Room 6 (y=720..925) carries straight on into Admission above its left wall.
- Walkable area: `room6Mask`, a bitmap of 5px cells (160x344) made from the art (tiled floor not covered by walls, the elevator cabin and the grass/road courtyard minus tables, tree and bush). Positions are Room 6 pixels.
- Elevator door: press `E` next to it to open or close it (closed = solid, open = you can walk into the cabin). It is shared with other players (bit 1024 of the state value).
- Props that characters walk behind or in front of (tables, palm, bush, elevator door) are `room6Props`; `depth` is the y of the object's base. The right-hand fence is drawn in front of everything.
- Door 1 and the cabinet door (door 2) are part of the wall art, they are not interactive.

## Room 7 (street and guard post)

Room 7 is a 4000x500 room at world x=-800, y=1720: directly under Room 6 (x 0..800), Room 3 (x 800..2400) and Room 5 (x 2400..4000). Nothing in those rooms was moved or redrawn; the world is now 2220px tall (`WORLD_HEIGHT`).
Its art is in `Assets/Webp/room 7/` (every layer is 4000x500 with the same origin). Look for `Room 7` in `index.html`.

- Rooms 3, 5 and 6 <-> Room 7: walk down off the sidewalk at the bottom of any of them. The sidewalk (the beige strip), the yellow curb and the street are all walkable, so you can step from the sidewalk down to the road anywhere along the width.
- Walkable area and obstacles are `room7CanStand` and `room7Obstacles`. Positions are Room 7 pixels, so they can be read straight off the art. The blue bottom rail, the guard post (wall, turnstiles, gate, desk, locker) and the staff side behind the desk are solid.
- The static layers are `room7Layers` (guard wall, turnstiles, gate, desk, chairs); the bottom rail is drawn in front of characters.
- The drain grate at x~2835 is walkable.

## Sprint
- Desktop: hold **Shift** while walking (WASD / arrows). Phone / narrow window: swipe the joystick up onto the **lock icon** above it to lock sprint on (the ring turns orange); tap the lock to unlock.
- Tuning constants (search `SPRINT_SPEED_MULT` in `index.html`): speed x1.65, faster walk animation, forward lean.
- Effects: dust puffs at the feet, fading after-images, speed streaks and a lean. They are skipped when the OS has "reduce motion" on.
- Multiplayer: other players see your sprint (lean, faster steps, dust) via bit 11 (2048) of the state number; `server.js` now allows 12 bits. Older servers still work, they just won't show the sprint effect.

## NPC eyeglasses
- About 45% of the walking student NPCs get glasses (`GLASSES_CHANCE`, search `studentGlassesHead` in `index.html`). Styles: round, square, colourful, half-rim, reading, tinted and shades, each with random frame colours. They are drawn onto the 32x32 head sprite at the eye positions, so they flip correctly when the NPC turns.
- To add a style, add an entry to `GLASSES_STYLES` (shape: `round`, `square` or `half`; lens: `clear`, `warm`, `blue` or `dark`). To add a frame colour, add it to `GLASSES_FRAME_COLOURS`.

## Guard at the desk
- Room 7 has a guard standing on the ground just below the desk (`drawGuard`, `GUARD_X` / `GUARD_Y`, `GUARD_NAME` in `index.html`). Art: `Assets/Webp/room 7/guard head.webp`, `guard head blink.webp`, `guard body 1.webp`, `guard body 2.webp` (all 32x32, drawn at 2x).
- He has a ground shadow, a `Guard` name tag, and a small solid box in `room7Obstacles` so players walk around him.
- He is idle: the torso swaps between its two frames about once a second, and he blinks every 2 to 6 seconds (sometimes twice in a row). Every few seconds he also glances left or right and back (`updateGuardLook`): the eyes and mouth slide sideways inside the face, so no extra art is needed. Every 5 to 12 seconds he also turns to face the other way (the sprite is mirrored, with a quick squeeze in between). Change `GUARD_X` / `GUARD_Y` to move him (keep the obstacle box in step).
