let joinRoom;

const TRYSTERO_SOURCES = [
  'https://cdn.jsdelivr.net/npm/trystero@0.27.0/+esm',
  'https://esm.run/trystero@0.27.0'
];

async function loadTrystero() {
  let lastError;
  for (const source of TRYSTERO_SOURCES) {
    try {
      const module = await import(source);
      if (typeof module.joinRoom === 'function') {
        joinRoom = module.joinRoom;
        return;
      }
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error('Could not load multiplayer support.');
}

const APP_ID = 'campus-service-desk-capstone-v1';
const LOBBY_ID = 'public-server-list-v1';
const DISCOVERY_WAIT_MS = 2500;
const JOIN_TIMEOUT_MS = 30000; // relayed (TURN) connections on phones can take longer

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const newId = () => {
  if (crypto.randomUUID) return crypto.randomUUID().split('-').join('').slice(0, 12);
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  return [...bytes].map(value => value.toString(16).padStart(2, '0')).join('').slice(0, 12);
};

// ---------------------------------------------------------------------------------------------
// YOUR OWN TURN SERVER (strongly recommended for iPhones / mobile data).
// Phones on cellular networks usually cannot link directly to another player, so their traffic
// has to go through a TURN relay. The free public relay used below is shared and often overloaded.
// Get free private credentials (takes 2 minutes) from https://www.metered.ca/tools/openrelay/ or
// Cloudflare Calls TURN, then paste them here, for example:
//   { urls: ['turn:YOUR-HOST:80', 'turn:YOUR-HOST:443?transport=tcp', 'turns:YOUR-HOST:443?transport=tcp'],
//     username: 'YOUR-USERNAME', credential: 'YOUR-PASSWORD' }
// ---------------------------------------------------------------------------------------------
const MY_TURN_SERVERS = [];

const rtcConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun.cloudflare.com:3478' },
    ...MY_TURN_SERVERS,
    {
      urls: [
        'turn:openrelay.metered.ca:80',
        'turn:openrelay.metered.ca:443?transport=tcp',
        'turns:openrelay.metered.ca:443?transport=tcp'
      ],
      username: 'openrelayproject',
      credential: 'openrelayproject'
    }
  ]
  // No iceCandidatePoolSize: pre-gathering candidates makes Safari on iPhone slow to answer a join request.
};

function roomConfig(pin, maxUsers) {
  const config = { appId: APP_ID, identity: 'none', maxUsers, rtcConfig };
  if (pin) config.password = `campus-pin-${pin}`;
  return config;
}

function validServer(value) {
  return value
    && typeof value.id === 'string'
    && typeof value.name === 'string'
    && Number.isInteger(value.max)
    && Number.isInteger(value.count);
}

class PeerSession {
  constructor({ sid, pin, max, profile, info, host, announce }) {
    this.sid = sid;
    this.pin = pin || '';
    this.info = info;
    this.host = host;
    this.isHost = host;
    this.announce = announce;
    this.closed = false;
    this.room = joinRoom(roomConfig(pin, max), `game-${sid}`);
    this.profiles = this.room.makeUserState('profile', null, { maxBytes: 16384 });
    this.states = this.room.makeUserState('state', null, { maxBytes: 1024 });
    this.chatState = this.room.makeUserState('chat', null, { maxBytes: 512 });
    this.chatCount = 0;
    this.chatSeen = new Set();
    this.ready = this.room.getSelf().then(({ userId }) => {
      this.pid = userId;
      this.profiles.set(profile);
      return this;
    });

    this.profiles.onChange(() => {
      if (!this.host || !this.announce) return;
      const count = Object.keys(this.profiles.getAll()).length;
      this.info.count = count;
      this.announce({ ...this.info, count });
    });
  }

  async waitForPeer(locked) {
    await this.ready;
    if (Object.keys(this.room.getUsers()).length) return;

    await new Promise((resolve, reject) => {
      let settled = false;
      const finish = callback => value => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        offJoin();
        offError();
        callback(value);
      };
      const offJoin = this.room.onUserJoin(finish(resolve));
      let lastCode = '';
      const offError = this.room.onError(error => {
        if (error && error.code && error.code !== 'decrypt-failed' && error.code !== 'room-full') lastCode = String(error.code);
        if (error.code === 'decrypt-failed') finish(reject)(Object.assign(new Error('Wrong PIN. Try again.'), { code: 'pin' }));
        if (error.code === 'room-full') finish(reject)(Object.assign(new Error('That server is full.'), { code: 'full' }));
      });
      const timer = setTimeout(() => {
        console.warn('[multiplayer] join timed out', lastCode);
        const hint = lastCode ? ` (${lastCode})` : '';
        const error = new Error(locked
          ? 'Wrong PIN, or the host is no longer online.' + hint
          : 'Found the server but could not connect to the host. A strict network may be blocking the connection.' + hint);
        error.code = locked ? 'pin' : 'notfound';
        finish(reject)(error);
      }, JOIN_TIMEOUT_MS);
    });
  }

  start(handlers) {
    this.handlers = handlers;
    this.profiles.onChange((profile, meta) => {
      if (meta.self) return;
      if (meta.removed) handlers.onLeave(meta.userId);
      else if (profile) handlers.onPlayer(meta.userId, profile);
    }, { replay: true });
    this.states.onChange((state, meta) => {
      if (!meta.self && !meta.removed && Array.isArray(state)) {
        handlers.onSnapshot([[meta.userId, ...state]]);
      }
    }, { replay: true });
    // Chat travels two ways at once (a direct message and a state value), and the first copy to arrive wins.
    // Either path alone is enough, so chat keeps working even if one of them is unsupported or dropped.
    const deliver = (userId, data) => {
      if (!data || typeof data.m !== 'string' || !handlers.onChat) return;
      const uid = typeof data.u === 'string' && data.u ? data.u : userId;
      if (!uid || uid === this.pid) return;
      const key = `${uid}:${data.n}`;
      if (this.chatSeen.has(key)) return;
      this.chatSeen.add(key);
      if (this.chatSeen.size > 400) this.chatSeen = new Set([...this.chatSeen].slice(-200));
      if (Number.isFinite(data.t) && Math.abs(Date.now() - data.t) > 600000 && Date.now() > data.t) return; // very old message replayed to a late joiner
      handlers.onChat(uid, data.m);
    };
    this.chatState.onChange((value, meta) => {
      if (meta.self || meta.removed) return;
      deliver(meta.userId, value);
    });
    try {
      const action = this.room.makeAction('chat');
      let send;
      let receive;
      if (Array.isArray(action)) [send, receive] = action;
      else if (action) { send = action.send; receive = action.onReceive || action.receive || action.get; }
      if (typeof send === 'function') this.chatSend = send;
      if (typeof receive === 'function') receive((data, peerId) => deliver(peerId, data));
    } catch (error) {
      console.warn('[multiplayer] direct chat messages unavailable, using state fallback', error);
    }
    this.room.onError(error => {
      if (error.code === 'relay-failed' && !this.closed) {
        handlers.onDisconnected('Could not reach the multiplayer relays.');
      }
    });
  }

  sendState(state) {
    if (!this.closed) this.states.set(state);
  }

  sendProfile(profile) {
    if (!this.closed) this.profiles.set(profile);
  }

  sendChat(text) {
    if (this.closed) return;
    this.chatCount += 1;
    const data = { u: this.pid || '', n: this.chatCount, t: Date.now(), m: String(text).slice(0, 120) };
    try { if (this.chatSend) Promise.resolve(this.chatSend(data)).catch(() => {}); } catch { /* fall through to state */ }
    try { this.chatState.set(data); } catch { /* ignore */ }
  }

  resumeData() {
    return {
      mode: 'peer',
      role: this.host ? 'host' : 'guest',
      sid: this.sid,
      pin: this.pin,
      info: this.info
    };
  }

  leave() {
    if (this.closed) return;
    this.closed = true;
    if (this.host && this.announce) this.announce(null);
    Promise.resolve(this.states.clear()).catch(() => {});
    Promise.resolve(this.profiles.clear()).catch(() => {});
    Promise.resolve(this.chatState.clear()).catch(() => {});
    Promise.resolve(this.room.leave()).catch(() => {});
  }
}

class PeerNet {
  constructor() {
    this.mode = 'peer';
    this.lobby = joinRoom({ appId: APP_ID, identity: 'none', maxUsers: 64, rtcConfig }, LOBBY_ID);
    this.servers = this.lobby.makeUserState('server', null, {
      maxBytes: 2048,
      validate: value => value === null || validServer(value)
    });
    this.ready = this.lobby.getSelf().then(() => delay(DISCOVERY_WAIT_MS));
  }

  async ping() {
    await this.ready;
    return { ok: true, service: 'campus-p2p' };
  }

  async list() {
    await this.ready;
    const unique = new Map();
    Object.values(this.servers.getAll()).forEach(server => {
      if (!validServer(server)) return;
      const current = unique.get(server.id);
      if (!current || server.created > current.created) unique.set(server.id, server);
    });
    return [...unique.values()].sort((a, b) => b.created - a.created);
  }

  async create({ name, pin, max, profile }) {
    await this.ready;
    const sid = newId();
    const info = { id: sid, name, locked: Boolean(pin), max, count: 1, created: Date.now() };
    const announce = value => value === null ? this.servers.clear() : this.servers.set(value);
    const session = new PeerSession({ sid, pin, max, profile, info, host: true, announce });
    await session.ready;
    announce(info);
    return session;
  }

  async join({ sid, pin, profile }) {
    await this.ready;
    const entry = (await this.list()).find(server => server.id === sid);
    if (!entry) throw Object.assign(new Error('That server is no longer online.'), { code: 'notfound' });
    const session = new PeerSession({ sid, pin, max: entry.max, profile, info: entry, host: false, announce: null });
    try {
      await session.waitForPeer(entry.locked);
      return session;
    } catch (error) {
      session.leave();
      throw error;
    }
  }

  async resume(data, profile) {
    await this.ready;
    if (!data || !data.sid || !data.info) throw new Error('Missing saved multiplayer session.');
    const host = data.role === 'host';
    const info = { ...data.info };
    const announce = host
      ? value => value === null ? this.servers.clear() : this.servers.set(value)
      : null;
    const session = new PeerSession({
      sid: data.sid,
      pin: data.pin || '',
      max: info.max,
      profile,
      info,
      host,
      announce
    });
    await session.ready;
    if (host) announce({ ...info, count: 1 });
    else await session.waitForPeer(Boolean(info.locked));
    return session;
  }
}

loadTrystero().then(() => {
  window.campusP2P = new PeerNet();
  window.dispatchEvent(new CustomEvent('campus-p2p-ready', { detail: window.campusP2P }));
}).catch(error => {
  window.campusP2PError = error;
  window.dispatchEvent(new CustomEvent('campus-p2p-ready', { detail: null }));
});

