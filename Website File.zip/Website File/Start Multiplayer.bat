@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-multiplayer.ps1"
if errorlevel 1 (
  echo.
  echo Multiplayer could not start. Check the message above.
  pause
)

