#!/usr/bin/env node
/*
 * Campus Service Desk - multiplayer server
 *
 * Zero dependencies. Needs Node 18 or newer.
 *
 *   node server.js            (then open http://localhost:3000)
 *   PORT=8080 node server.js
 *
 * It serves index.html + Assets and a small JSON/SSE API:
 *   GET  /api/ping
 *   GET  /api/servers                    list of open servers
 *   POST /api/create                     create a server and join it
 *   POST /api/join                       join a server (PIN checked here)
 *   GET  /api/events?s=&p=&t=            Server-Sent Events stream for one player
 *   POST /api/state | /api/profile | /api/chat | /api/leave
 *
 * Servers live in memory only. They disappear when everyone has left.
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = __dirname;

const MAX_SERVERS = 200;
const MAX_BODY = 24 * 1024;
const MAX_HEAD_DATA = 12000;     // size cap for a player's 32x32 head PNG (as a data URL)
const NO_STREAM_GRACE_MS = 12000; // a player with no open event stream is dropped after this
const EMPTY_SERVER_MS = 15000;    // an empty server is deleted after this
const TICK_MS = 66;               // position broadcast rate (about 15 per second)
const PIN_TRIES = 5;
const PIN_LOCK_MS = 30000;

const servers = new Map();
const pinFailures = new Map();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg',
  '.wav': 'audio/wav'
};

// ---------------------------------------------------------------- helpers
class HttpError extends Error {
  constructor(status, code, message) {
    super(message || code);
    this.status = status;
    this.code = code;
  }
}

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  setCors(res);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(new HttpError(413, 'too_large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        resolve(parsed && typeof parsed === 'object' ? parsed : {});
      } catch {
        reject(new HttpError(400, 'bad_json'));
      }
    });
    req.on('error', reject);
  });
}

function cleanText(value, max) {
  const text = String(value == null ? '' : value)
    .replace(/[\u0000-\u001f\u007f<>]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  return Array.from(text).slice(0, max).join('');
}

function cleanProfile(p) {
  if (!p || typeof p !== 'object') return null;
  const name = cleanText(p.name, 16);
  if (!name) return null;
  const uniform = typeof p.uniform === 'string' && /^[a-z0-9_-]{1,24}$/i.test(p.uniform) ? p.uniform : 'base';
  let head = null;
  const prefix = 'data:image/png;base64,';
  if (typeof p.head === 'string' && p.head.startsWith(prefix) && p.head.length <= MAX_HEAD_DATA
      && /^[A-Za-z0-9+/=]+$/.test(p.head.slice(prefix.length))) {
    head = p.head;
  }
  return { name, uniform, head };
}

function clampInt(value, min, max) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n)) return null;
  return Math.max(min, Math.min(max, n));
}

function cleanState(st) {
  if (!Array.isArray(st) || st.length < 5) return null;
  const x = clampInt(st[0], -200, 4100);   // room 3 is 1600 px wide, room 4 is 2400 and room 7 is 4000
  const y = clampInt(st[1], -200, 1800);   // room 6 is 1720 px tall
  const room = st[2] === 7 ? 7 : st[2] === 6 ? 6 : st[2] === 5 ? 5 : st[2] === 4 ? 4 : st[2] === 3 ? 3 : st[2] === 2 ? 2 : 1;
  const face = st[3] === 0 ? 0 : 1;
  const moving = (Number(st[4]) | 0) & 4095; // bit0 walking, bits1-3 door states, bits4-8 lift height, bits9-10 elevators, bit11 sprint
  if (x === null || y === null) return null;
  const state = [x, y, room, face, moving];
  if (st.length >= 10) {
    const professorX = clampInt(st[5], -200, 1900);
    const professorY = clampInt(st[6], -200, 900);
    if (professorX !== null && professorY !== null) {
      state.push(
        professorX,
        professorY,
        st[7] === 3 ? 3 : st[7] === 2 ? 2 : 1,
        st[8] === 0 ? 0 : 1,
        st[9] ? 1 : 0
      );
      if (st.length >= 11 && state.length === 10) state.push(st[10] ? 1 : 0); // host's Lift and drop switch
    }
  }
  return state;
}

function clientIp(req) {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || req.socket.remoteAddress || 'unknown';
}

const newId = bytes => crypto.randomBytes(bytes).toString('hex');

function sse(res, event, data) {
  res.write('event: ' + event + '\ndata: ' + JSON.stringify(data) + '\n\n');
}

function broadcast(server, event, data, exceptId) {
  for (const player of server.players.values()) {
    if (player.id !== exceptId && player.res) sse(player.res, event, data);
  }
}

function publicInfo(server) {
  return { id: server.id, name: server.name, locked: !!server.pin, max: server.max, count: server.players.size };
}

function tokensMatch(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

function getPlayer(body) {
  const server = servers.get(String(body.s));
  const player = server && server.players.get(String(body.p));
  if (!server || !player) throw new HttpError(404, 'gone', 'Player or server no longer exists');
  if (!tokensMatch(player.token, body.t)) throw new HttpError(403, 'forbidden');
  return { server, player };
}

// ---------------------------------------------------------------- server logic
function addPlayer(server, profile) {
  const player = {
    id: newId(4),
    token: newId(16),
    profile,
    state: null,
    res: null,
    createdAt: Date.now(),
    disconnectedAt: 0
  };
  server.players.set(player.id, player);
  server.emptySince = 0;
  broadcast(server, 'join', { id: player.id, profile }, player.id);
  return player;
}

function removePlayer(server, id) {
  const player = server.players.get(id);
  if (!player) return;
  server.players.delete(id);
  server.dirty.delete(id);
  if (player.res) {
    try { player.res.end(); } catch { /* already closed */ }
    player.res = null;
  }
  broadcast(server, 'leave', { id });
  if (!server.players.size) server.emptySince = Date.now();
}

function checkPin(server, pin, ip) {
  if (!server.pin) return;
  const key = ip + '|' + server.id;
  const record = pinFailures.get(key);
  const now = Date.now();
  if (record && record.until > now) throw new HttpError(429, 'locked', 'Too many wrong PINs');
  if (typeof pin === 'string' && tokensMatch(pin.padEnd(8), server.pin.padEnd(8)) && pin === server.pin) {
    pinFailures.delete(key);
    return;
  }
  const expired = record && record.until && record.until <= now;
  const next = { n: (record && !expired ? record.n : 0) + 1, until: 0 };
  if (next.n >= PIN_TRIES) next.until = now + PIN_LOCK_MS;
  pinFailures.set(key, next);
  throw new HttpError(403, 'pin', 'Wrong PIN');
}

function sessionReply(server, player) {
  return { sid: server.id, pid: player.id, token: player.token, info: publicInfo(server), host: player.id === server.hostId };
}

async function handleCreate(req, res) {
  const body = await readBody(req);
  const name = cleanText(body.name, 24);
  const max = clampInt(body.max, 2, 30);
  const profile = cleanProfile(body.profile);
  const pin = body.pin === null || body.pin === undefined || body.pin === '' ? null : String(body.pin);
  if (!name) throw new HttpError(400, 'bad_name', 'Give the server a name');
  if (max === null) throw new HttpError(400, 'bad_max', 'Max players must be 2 to 30');
  if (!profile) throw new HttpError(400, 'bad_profile', 'Missing player name');
  if (pin !== null && !/^\d{4}$/.test(pin)) throw new HttpError(400, 'bad_pin', 'PIN must be 4 digits');
  if (servers.size >= MAX_SERVERS) throw new HttpError(503, 'busy', 'Too many servers right now');

  const server = {
    id: newId(4),
    name,
    max,
    pin,
    created: Date.now(),
    emptySince: 0,
    hostId: null,
    players: new Map(),
    dirty: new Set()
  };
  servers.set(server.id, server);
  const player = addPlayer(server, profile);
  server.hostId = player.id;
  sendJson(res, 200, sessionReply(server, player));
}

async function handleJoin(req, res) {
  const body = await readBody(req);
  const server = servers.get(String(body.sid));
  const profile = cleanProfile(body.profile);
  if (!server) throw new HttpError(404, 'notfound', 'That server no longer exists');
  if (!profile) throw new HttpError(400, 'bad_profile', 'Missing player name');
  checkPin(server, body.pin == null ? '' : String(body.pin), clientIp(req));
  if (server.players.size >= server.max) throw new HttpError(409, 'full', 'Server is full');
  const player = addPlayer(server, profile);
  sendJson(res, 200, sessionReply(server, player));
}

function handleEvents(req, res, url) {
  const { server, player } = getPlayer({
    s: url.searchParams.get('s'),
    p: url.searchParams.get('p'),
    t: url.searchParams.get('t')
  });
  setCors(res);
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no'
  });
  res.write('retry: 1500\n\n');

  if (player.res && player.res !== res) {
    try { player.res.end(); } catch { /* ignore */ }
  }
  player.res = res;
  player.disconnectedAt = 0;

  const others = [];
  const states = [];
  for (const other of server.players.values()) {
    if (other.id === player.id) continue;
    others.push({ id: other.id, profile: other.profile });
    if (other.state) states.push([other.id, ...other.state]);
  }
  sse(res, 'init', { you: player.id, players: others, states });
  if (player.state) server.dirty.add(player.id); // reconnects re-announce where the player is

  req.on('close', () => {
    if (player.res === res) {
      player.res = null;
      player.disconnectedAt = Date.now();
    }
  });
}

async function handleApi(req, res, url) {
  const route = url.pathname;

  if (req.method === 'OPTIONS') {
    setCors(res);
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method === 'GET' && route === '/api/ping') {
    return sendJson(res, 200, { ok: true, service: 'campus-service-desk', servers: servers.size });
  }

  if (req.method === 'GET' && route === '/api/servers') {
    const list = [...servers.values()]
      .filter(s => s.players.size > 0)
      .sort((a, b) => b.created - a.created)
      .map(publicInfo);
    return sendJson(res, 200, { servers: list });
  }

  if (req.method === 'GET' && route === '/api/events') return handleEvents(req, res, url);

  if (req.method !== 'POST') throw new HttpError(404, 'not_found');

  if (route === '/api/create') return handleCreate(req, res);
  if (route === '/api/join') return handleJoin(req, res);

  const body = await readBody(req);
  const { server, player } = getPlayer(body);

  if (route === '/api/state') {
    const state = cleanState(body.st);
    if (!state) throw new HttpError(400, 'bad_state');
    player.state = state;
    server.dirty.add(player.id);
    return sendJson(res, 200, { ok: true });
  }

  if (route === '/api/profile') {
    const profile = cleanProfile(body.profile);
    if (!profile) throw new HttpError(400, 'bad_profile');
    player.profile = profile;
    broadcast(server, 'profile', { id: player.id, profile }, player.id);
    return sendJson(res, 200, { ok: true });
  }

  if (route === '/api/chat') {
    const text = String(body.text == null ? '' : body.text).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
    if (!text) throw new HttpError(400, 'bad_chat');
    const nowMs = Date.now();
    if (nowMs - (player.lastChat || 0) < 500) return sendJson(res, 200, { ok: true });
    player.lastChat = nowMs;
    broadcast(server, 'chat', { id: player.id, text }, player.id);
    return sendJson(res, 200, { ok: true });
  }

  if (route === '/api/leave') {
    removePlayer(server, player.id);
    return sendJson(res, 200, { ok: true });
  }

  throw new HttpError(404, 'not_found');
}

// ---------------------------------------------------------------- static files
function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405);
    return res.end();
  }
  let rel;
  try {
    rel = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
  } catch {
    res.writeHead(400);
    return res.end('Bad request');
  }
  if (rel.includes('\0') || (rel !== '/index.html' && rel !== '/multiplayer-p2p.js' && rel !== '/manifest.webmanifest' && !rel.startsWith('/Assets/'))) {
    res.writeHead(404);
    return res.end('Not found');
  }
  const file = path.normalize(path.join(ROOT, rel));
  if (!file.startsWith(ROOT + path.sep)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404);
      return res.end('Not found');
    }
    const ext = path.extname(file).toLowerCase();
    const headers = {
      'Content-Type': MIME[ext] || (ext === '.webmanifest' ? 'application/manifest+json' : 'application/octet-stream'),
      'Cache-Control': rel === '/index.html' ? 'no-cache' : 'public, max-age=86400, stale-while-revalidate=604800'
    };
    // index.html is ~200 KB of text: gzip cuts it to roughly a quarter, which matters on slow Wi-Fi.
    const gzip = (ext === '.html' || ext === '.js') && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
    if (!gzip) headers['Content-Length'] = stat.size;
    else { headers['Content-Encoding'] = 'gzip'; headers['Vary'] = 'Accept-Encoding'; }
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    if (gzip) fs.createReadStream(file).pipe(require('zlib').createGzip({ level: 6 })).pipe(res);
    else fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  let url;
  try {
    url = new URL(req.url, 'http://localhost');
  } catch {
    res.writeHead(400);
    return res.end('Bad request');
  }
  if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url);
  try {
    await handleApi(req, res, url);
  } catch (err) {
    if (res.headersSent) return;
    if (err instanceof HttpError) {
      sendJson(res, err.status, { error: err.code, message: err.message });
    } else {
      console.error(err);
      sendJson(res, 500, { error: 'server_error' });
    }
  }
});

// Position broadcasts: only players that changed since the last tick are sent.
setInterval(() => {
  for (const s of servers.values()) {
    if (!s.dirty.size) continue;
    const snap = [];
    for (const id of s.dirty) {
      const p = s.players.get(id);
      if (p && p.state) snap.push([id, ...p.state]);
    }
    s.dirty.clear();
    if (snap.length) broadcast(s, 'snap', snap);
  }
}, TICK_MS);

// Housekeeping: dead connections, abandoned players, empty servers.
setInterval(() => {
  const now = Date.now();
  for (const s of [...servers.values()]) {
    for (const p of [...s.players.values()]) {
      if (p.res) continue;
      if (now - (p.disconnectedAt || p.createdAt) > NO_STREAM_GRACE_MS) removePlayer(s, p.id);
    }
    if (!s.players.size && s.emptySince && now - s.emptySince > EMPTY_SERVER_MS) servers.delete(s.id);
  }
  for (const [key, record] of pinFailures) {
    if (record.until && record.until < now) pinFailures.delete(key);
  }
}, 3000);

// Keeps proxies from closing idle event streams.
setInterval(() => {
  for (const s of servers.values()) {
    for (const p of s.players.values()) if (p.res) p.res.write(': ping\n\n');
  }
}, 15000);

server.on('connection', socket => socket.setNoDelay(true));
server.keepAliveTimeout = 65000;

server.listen(PORT, HOST, () => {
  console.log('Campus Service Desk is running.');
  console.log('  This computer:  http://localhost:' + PORT);
  console.log('  Same Wi-Fi:     http://<this computer\'s IP address>:' + PORT);
});
